package edu.itu.exchangeratewizard.model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import edu.itu.exchangeratewizard.common.Util;

/**
 * @author nithya
 *
 */
public class DbHelper extends SQLiteOpenHelper {

	public static final String DB_NAME = "exchangeratewizarddb";
	public static final int DB_VERSION = 1;
	
	public static final String COL_CURRENCY_NAME = "currency_name";

	public DbHelper(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(edu.itu.exchangeratewizard.model.Symbol.getSql());
		db.execSQL(edu.itu.exchangeratewizard.model.Quote.getSql());
		db.execSQL(edu.itu.exchangeratewizard.model.Rate.getSql());
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	}

	private final String currencyFormat = "%s || ' ' || %s || ' (' || %s || ')' AS "+COL_CURRENCY_NAME;
	private final String listSQL = Util.concat("SELECT ",
													"s."+ edu.itu.exchangeratewizard.model.Symbol.COL_ID+", ",
													String.format(currencyFormat, "s."+ edu.itu.exchangeratewizard.model.Symbol.COL_COUNTRY, "s."+ edu.itu.exchangeratewizard.model.Symbol.COL_CURRENCY, "s."+ edu.itu.exchangeratewizard.model.Symbol.COL_CURRENCY_CODE)+", ",
													"s."+ edu.itu.exchangeratewizard.model.Symbol.COL_CURRENCY_CODE+", ",
													"s."+ edu.itu.exchangeratewizard.model.Symbol.COL_FLAG+", ",
													"q."+ edu.itu.exchangeratewizard.model.Quote.COL_NAME+", ",
													"q."+ edu.itu.exchangeratewizard.model.Quote.COL_PRICE+", ",
													"q."+ edu.itu.exchangeratewizard.model.Quote.COL_TS,
											" FROM "+ edu.itu.exchangeratewizard.model.Symbol.TABLE_NAME+" AS s",
											" JOIN "+ edu.itu.exchangeratewizard.model.Quote.TABLE_NAME+" AS q",
											" ON s."+ edu.itu.exchangeratewizard.model.Symbol.COL_CURRENCY_CODE+" = q."+ edu.itu.exchangeratewizard.model.Quote.COL_SYMBOL);

	/**
	 * @param db
	 * @return cursor
	 */
	public Cursor listRates(SQLiteDatabase db) {
		String selection = "s."+ edu.itu.exchangeratewizard.model.Symbol.COL_TRACKED+" = ?";
		String sql = Util.concat(listSQL,
								" WHERE "+selection,
								" ORDER BY s."+ edu.itu.exchangeratewizard.model.Symbol.COL_ORDER+" DESC");

		return db.rawQuery(sql, new String[]{edu.itu.exchangeratewizard.model.Symbol.TRACKED});
	}	

}
