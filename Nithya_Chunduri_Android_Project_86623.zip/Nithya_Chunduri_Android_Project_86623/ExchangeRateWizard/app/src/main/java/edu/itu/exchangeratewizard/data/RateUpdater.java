package edu.itu.exchangeratewizard.data;

import android.database.sqlite.SQLiteDatabase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;

import edu.itu.exchangeratewizard.common.Constants;

/**
 * @author nithya
 *
 */
public class RateUpdater {
	
	//private static final String TAG = "RateUpdater";
	
	public static final String[] tags = {"s","a","b","l1","d1","t1"};
	private static final String URL = "http://finance.yahoo.com/d/quotes.csv?e=.csv&f=";//sabl1d1t1&s=EURUSD=X
	
	private SQLiteDatabase db;
	private Downloader downloader;
	
	public RateUpdater(SQLiteDatabase db, Downloader downloader) {
		super();
		this.db = db;
		this.downloader = downloader;
	}
	
	private String getUrl(String... pair) {

		StringBuilder url = new StringBuilder(URL);
		for(String tag : tags) {
			url.append(tag);
		}
		for(String item : pair) {
			url.append("&s=").append(item).append("=X");
		}
		
		return url.toString();
	}
	
	public boolean populate(String... pair) {
		BufferedReader br = null;
		
		db.beginTransaction();	
		try {
			String result = downloader.getResult(getUrl(pair));
			if (result == null) return false;
			
			br = new BufferedReader(new StringReader(result));
			RateLoader.populate(db, br, Constants.UPDATE);
			db.setTransactionSuccessful();
			
		} catch (Exception e) {
			//Log.e(TAG, e.getMessage(), e);
			return false;
		} finally {
			db.endTransaction();
			try {
				if (br!=null) br.close();
			} catch (IOException e) {}
		}
		
		return true;
	}

}
