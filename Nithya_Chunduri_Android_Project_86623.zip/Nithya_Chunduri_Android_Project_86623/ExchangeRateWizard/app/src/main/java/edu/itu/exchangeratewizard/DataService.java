package edu.itu.exchangeratewizard;

import android.app.IntentService;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import edu.itu.exchangeratewizard.common.Constants;
import edu.itu.exchangeratewizard.data.Downloader;
import edu.itu.exchangeratewizard.data.QuoteUpdater;
import edu.itu.exchangeratewizard.data.RateUpdater;
import edu.itu.exchangeratewizard.model.Symbol;

/**
 * @author nithya
 *
 */
public class DataService extends IntentService {
	
	private static final String TAG = "DataService";
	private static final String HISTORY_URL = "http://finance.yahoo.com/d/quotes.csv?e=.csv&f=";//c4abd1l1t1&s=EURUSD=X
	
	public static final String EXTRA_PAIR = "pair";
//	public static final String EXTRA_TYPE = "type";
	public static final String EXTRA_FORCE = "force";
	
/*	public static final int ONETIME = 1;
	public static final int DAILY = 0;
	public static final int NEWADDITION = 2;*/
	
	private SQLiteDatabase db;

	public DataService() {
		super(TAG);
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		db = edu.itu.exchangeratewizard.ExchangeRateWizard.db;
	}

	/*
	 * onetimeRefresh(tracked)
	 * dailyRefresh(all)
	 * newadditionRefresh(...pair)
	 */
	@Override
	protected void onHandleIntent(Intent intent) {
		Downloader downloader = new Downloader(this);
		if (!downloader.isConnected()) {
			broadcastStatus(Constants.STATUS_NOCONNECTIVITY);
			return;
		}

		broadcastStatus(Constants.STATUS_INPROGRESS);
		long now = System.currentTimeMillis();

		//update
		if (edu.itu.exchangeratewizard.ExchangeRateWizard.isReadyForUpdate(now) || intent.getBooleanExtra(EXTRA_FORCE, false)) {
			QuoteUpdater qu = new QuoteUpdater(db);
			if (!qu.populate()) {
				broadcastStatus(Constants.STATUS_FAILED);
				return;
			}
			edu.itu.exchangeratewizard.ExchangeRateWizard.setLastUpdate(now);
		}

		//refresh
		String[] pair = intent.getStringArrayExtra(EXTRA_PAIR);
		if (pair == null) pair = getPair();

		if (pair != null) {
			RateUpdater ru = new RateUpdater(db, downloader);
			if (!ru.populate(pair)) {
				broadcastStatus(Constants.STATUS_FAILED);
				return;
			}
		}

		broadcastStatus(Constants.STATUS_SUCCESS);
	}

	private String[] getPair() {
		String[] pair = null;
		String baseCurrency = edu.itu.exchangeratewizard.ExchangeRateWizard.getBaseCurrency();

		Cursor c = Symbol.list(db, Symbol.TRACKED);
		if (c.moveToFirst()) {
			int n = c.getCount();
			pair = new String[n];
			int columnIndex = c.getColumnIndex(Symbol.COL_CURRENCY_CODE);
			for(int i=0; i<n; i++) {
				pair[i] = baseCurrency+c.getString(columnIndex);//USDINR
				c.moveToNext();
			}
		}
		c.close();

		return pair;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		db = null;
	}

	private void broadcastStatus(int status) {
		switch(status) {
		case Constants.STATUS_INPROGRESS:
			edu.itu.exchangeratewizard.ExchangeRateWizard.setProgress(true);
			break;

		case Constants.STATUS_FAILED:
		case Constants.STATUS_SUCCESS:
			ExchangeRateWizard.setProgress(false);
			break;			
		}
		
		Intent intent = new Intent(Constants.ACTION_REFRESH);
		intent.putExtra(Constants.EXTRA_STATUS, status);
		sendBroadcast(intent);		
	}

}
