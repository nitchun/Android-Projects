package edu.itu.exchangeratewizard;

import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.text.TextUtils;

/**
 * @author nithya
 *
 */
public class SettingsActivity extends PreferenceActivity implements OnSharedPreferenceChangeListener {
	
	//private static final String TAG = "SettingsActivity";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
    }
    
	@Override
	protected void onResume(){
		super.onResume();
		getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
		updatePreferences();
	}

	@Override
	protected void onPause() {
		super.onPause();
		getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
	}	

	@Override
	public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
		updatePreference(key);
	}
	
	private void updatePreferences() {
		updatePreference(edu.itu.exchangeratewizard.ExchangeRateWizard.BASE_CURRENCY);
		updatePreference(edu.itu.exchangeratewizard.ExchangeRateWizard.BASE_AMOUNT);
		updatePreference(edu.itu.exchangeratewizard.ExchangeRateWizard.HISTORY_VISIBLE);
		updatePreference(edu.itu.exchangeratewizard.ExchangeRateWizard.HISTORY_TOTAL);
		updatePreference(edu.itu.exchangeratewizard.ExchangeRateWizard.USE_WIFI);
	}

	private void updatePreference(String key){
		Preference pref = findPreference(key);

	    if (pref instanceof ListPreference) {
	        ListPreference listPref = (ListPreference) pref;
	        pref.setSummary(listPref.getEntry());
	        return;
	    }

		if (edu.itu.exchangeratewizard.ExchangeRateWizard.BASE_AMOUNT.equals(key)){
			EditTextPreference editPreference = (EditTextPreference) pref;
			String txt = editPreference.getText();

			if (TextUtils.isEmpty(txt)) {
				txt = edu.itu.exchangeratewizard.ExchangeRateWizard.DEFAULT_AMOUNT;
				editPreference.setText(txt);
			}
			editPreference.setSummary(String.valueOf(Float.parseFloat(txt)));
		}

/*		if (ExchangeRateWizard.UPDATE_FREQUENCY.equals(key)){
			EditTextPreference editPreference = (EditTextPreference) pref;
			String txt = editPreference.getText();

			if (TextUtils.isEmpty(txt) || Integer.parseInt(txt) < ExchangeRateWizard.MIN_UPDATE) {
				txt = ExchangeRateWizard.DEFAULT_UPDATE;
				editPreference.setText(txt);
			}
			editPreference.setSummary(txt + " day");
		}*/

		if (ExchangeRateWizard.USE_WIFI.equals(key)) {
			CheckBoxPreference cbPreference = (CheckBoxPreference) pref;
			if (cbPreference.isChecked()) {
				cbPreference.setSummary(getString(R.string.wifi));
			} else {
				cbPreference.setSummary(getString(R.string.wifi_mobile));
			}
		}
	}	

}
