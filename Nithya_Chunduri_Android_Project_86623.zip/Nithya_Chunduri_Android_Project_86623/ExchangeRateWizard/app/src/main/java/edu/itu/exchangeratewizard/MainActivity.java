package edu.itu.exchangeratewizard;

import android.app.ListActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import edu.itu.exchangeratewizard.common.Constants;
import edu.itu.exchangeratewizard.common.Util;
import edu.itu.exchangeratewizard.model.DbHelper;
import edu.itu.exchangeratewizard.model.Quote;
import edu.itu.exchangeratewizard.model.Symbol;

/**
 * @author nithya
 *
 */
public class MainActivity extends ListActivity {
	
	private DbHelper dbHelper;
	private SQLiteDatabase db;
	private Resources res;
	private Typeface font;
	
	private TextView headingText;
	private Spinner baseSpinner;
	private ImageButton baseBtn;
	private EditText baseEdit;
	private ImageView processImg;
	
	private Animation animation;
	private Handler handler;
	
	private Symbol symbol;
	private Quote quote;
	private String[] baseArr;
	
	int lastViewedPosition, topOffset;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main);
		
		dbHelper = ExchangeRateWizard.dbHelper;
		db = ExchangeRateWizard.db;
		res = getResources();
		
		symbol = new Symbol();
		quote = new Quote();
		baseArr = res.getStringArray(R.array.base_codes);
		
		headingText = (TextView) findViewById(R.id.heading_tv);
		baseSpinner = (Spinner) findViewById(R.id.base_spn);
		baseBtn = (ImageButton) findViewById(R.id.base_btn);
		baseEdit = (EditText) findViewById(R.id.base_et);
		processImg = (ImageView) findViewById(R.id.process_iv);
		
		animation = AnimationUtils.loadAnimation(this, R.anim.progress);
		
        font = Typeface.createFromAsset(getAssets(), "fonts/OpenSans-Semibold.ttf");
        headingText.setTypeface(font);
        
        baseSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				String baseCurrency = baseArr[position];
				if (!baseCurrency.equals(symbol.getCurrencyCode())) {
					ExchangeRateWizard.setBaseCurrency(baseCurrency);
					load(baseCurrency);
					doRefresh(false);
				}
				
				int flag = res.getIdentifier(symbol.getFlag(), "drawable", getBaseContext().getPackageName());//"edu.itu.exchangeratewizard");
				//getResources().getIdentifier("fr_200_133", "drawable", getPackageName());
				baseBtn.setImageResource(flag);
				
				getListView().invalidateViews();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {}
		});
        
        baseEdit.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
			
			@Override
			public void afterTextChanged(Editable s) {
				getListView().invalidateViews();
			}
		});
        
        registerForContextMenu(getListView());
        
        handler = new Handler();
        doRefresh(false);
	}
	
	private void doRefresh(boolean force) {
		if (ExchangeRateWizard.inProgress()) return;
		
        handler.postDelayed(new Runnable() {
			
			@Override
			public void run() {
				Intent onetimeRefresh = new Intent(getApplicationContext(), DataService.class);
				onetimeRefresh.putExtra(DataService.EXTRA_FORCE, true);
				startService(onetimeRefresh);				
			}
		}, 500);		
	}
	
	private void load(String baseCurrency) {
		symbol.reset();
		symbol.setCurrencyCode(baseCurrency);
		symbol.find(db);

		quote.reset();
		quote.setSymbol(baseCurrency);
		quote.find(db);
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putInt("lastViewedPosition", lastViewedPosition);
		outState.putInt("topOffset", topOffset);
	}	

	@Override
	protected void onRestoreInstanceState(Bundle state) {
		super.onRestoreInstanceState(state);
		lastViewedPosition = state.getInt("lastViewedPosition");
		topOffset = state.getInt("topOffset");
	}	
	
	@Override
	protected void onResume() {
		super.onResume();
		
		registerReceiver(refreshStatusReceiver, new IntentFilter(Constants.ACTION_REFRESH));
		
		String baseCurrency = ExchangeRateWizard.getBaseCurrency();
        load(baseCurrency);
        baseSpinner.setSelection(Util.getPosition(baseArr, baseCurrency));
        
        if (TextUtils.isEmpty(baseEdit.getText().toString())) 
        	baseEdit.setText(String.valueOf(ExchangeRateWizard.getBaseAmount()));
		
		Cursor c = dbHelper.listRates(db);
		startManagingCursor(c);
		SimpleCursorAdapter adapter = new SimpleCursorAdapter(
				this, 
				R.layout.row, 
				c, 
				new String[]{DbHelper.COL_CURRENCY_NAME, Quote.COL_NAME, Quote.COL_PRICE}, 
				new int[]{R.id.text1, R.id.text2, R.id.text3});
		
		adapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {
			
			@Override
			public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
				TextView tv = (TextView) view;
				switch(view.getId()) {
				case R.id.text1:
					RelativeLayout parent = (RelativeLayout) view.getParent();
					Util.fixBackgroundRepeat(parent);
					
					int left = res.getIdentifier(cursor.getString(cursor.getColumnIndex(Symbol.COL_FLAG)), "drawable", getBaseContext().getPackageName());

					tv.setText(cursor.getString(columnIndex));
					tv.setCompoundDrawablesWithIntrinsicBounds(left, 0, 0, 0);
					tv.setCompoundDrawablePadding(10);
					return true;
					
				case R.id.text2:
				case R.id.text3:
					String[] pair = cursor.getString(cursor.getColumnIndex(Quote.COL_NAME)).split("/");
					String amtStr = baseEdit.getText().toString();
					if (TextUtils.isEmpty(amtStr))
						amtStr = String.valueOf(ExchangeRateWizard.getBaseAmount());
					if (amtStr.endsWith(".0")) 
						amtStr = amtStr.replace(".0", "");
					
					double price = Util.parseDouble(cursor.getString(cursor.getColumnIndex(Quote.COL_PRICE)));
					double amt = Util.parseDouble(amtStr);
					
					if (!pair[0].equals(quote.getSymbol())) {
						price /= Util.parseDouble(quote.getPrice());
					}
					
					if (view.getId() == R.id.text2) {
						tv.setText(String.format("%s %s = %f %s", amtStr, quote.getSymbol(), amt*price, pair[1]));
					} else if (view.getId() == R.id.text3) {
						tv.setText(String.format("%s %s = %f %s", amtStr, pair[1], amt/price, quote.getSymbol()));
					}
					return true;					
				}
				return false;
			}
		});		
		
		setListAdapter(adapter);
		
		getListView().setSelectionFromTop(lastViewedPosition, topOffset);
		baseEdit.clearFocus();
	}
	
	private void viewInfo(long id) {
		Intent intent = new Intent(this, InfoActivity.class);
		intent.putExtra(Symbol.COL_ID, id);
		startActivity(intent);	
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		viewInfo(id);
	}	

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		if (v.getId() == android.R.id.list) {
			getMenuInflater().inflate(R.menu.context, menu);
			menu.setHeaderTitle("Choose an Option");
			menu.setHeaderIcon(R.drawable.ic_dialog_menu_generic);			
		}
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
		
		switch (item.getItemId()) {
		case R.id.menu_view:
			viewInfo(info.id);
			break;
			
		case R.id.menu_remove:
			Symbol s = new Symbol(info.id);
			s.setTracked(false);
			s.persist(db);
			
	    	SimpleCursorAdapter adapter = (SimpleCursorAdapter) getListAdapter();
	    	adapter.getCursor().requery();
	    	adapter.notifyDataSetChanged();	    	
			break;			
		}
		return true;
	}

	@Override
	protected void onPause() {
		unregisterReceiver(refreshStatusReceiver);
		processImg.clearAnimation();
		processImg.setVisibility(View.INVISIBLE);
		
	    lastViewedPosition = getListView().getFirstVisiblePosition();
	    View v = getListView().getChildAt(0);
	    topOffset = (v == null) ? 0 : v.getTop();
	    
		super.onPause();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.options, menu);
		return true;
	}
	
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
        if (getListAdapter().isEmpty()) {
        	menu.findItem(R.id.menu_refresh).setEnabled(false);
        } else {
        	menu.findItem(R.id.menu_refresh).setEnabled(true);
        }
		return true;
	}	

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menu_refresh:
			doRefresh(true);			
			return true;
		}		
		return super.onOptionsItemSelected(item);
	}	
	
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.add_btn:
			onSearchRequested();
			break;
			
		case R.id.base_btn:
			baseSpinner.performClick();
			break;
			
		case R.id.more:
			openContextMenu(v);
			break;
			
		case R.id.settings_btn:
			Intent settings = new Intent();
			settings.setClass(this, SettingsActivity.class);
			startActivity(settings);
			break;			
		}
	}
	
	//---------------------------------------------------------------------------
	
	private Runnable inprogress = new Runnable() {
		
		@Override
		public void run() {
			processImg.setVisibility(View.VISIBLE);
			processImg.startAnimation(animation);			
		}
	};
	
	private Runnable complete = new Runnable() {
		
		@Override
		public void run() {
			processImg.clearAnimation();
			processImg.setVisibility(View.INVISIBLE);
			
			SimpleCursorAdapter adapter = (SimpleCursorAdapter) getListAdapter();
			adapter.notifyDataSetChanged();
			getListView().invalidateViews();
		}
	};	
	
	private BroadcastReceiver refreshStatusReceiver = new  BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent != null && Constants.ACTION_REFRESH.equals(intent.getAction())) {
				switch (intent.getIntExtra(Constants.EXTRA_STATUS, 100)) {
				case Constants.STATUS_NOCONNECTIVITY:
					if (ExchangeRateWizard.isUseWifi())
						Toast.makeText(context, getString(R.string.no_wifi), Toast.LENGTH_SHORT).show();
					else 
						Toast.makeText(context, getString(R.string.no_connectivity), Toast.LENGTH_SHORT).show();
					break;
					
				case Constants.STATUS_INPROGRESS:
					runOnUiThread(inprogress);
					break;
					
				case Constants.STATUS_FAILED:
					Toast.makeText(context, getString(R.string.update_failed), Toast.LENGTH_SHORT).show();

				case Constants.STATUS_SUCCESS:
					runOnUiThread(complete);					
					break;
				}
			}
		}
	};	

}
