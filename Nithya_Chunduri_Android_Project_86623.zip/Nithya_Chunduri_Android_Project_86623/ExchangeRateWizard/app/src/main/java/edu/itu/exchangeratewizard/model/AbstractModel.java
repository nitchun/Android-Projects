package edu.itu.exchangeratewizard.model;

import android.database.sqlite.SQLiteDatabase;

/**
 * @author nithya
 *
 */
abstract class AbstractModel {
	
	static final String COL_ID = "_id";
	
	protected long id;
	
	protected void reset() {
		id = 0;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	abstract long save(SQLiteDatabase db);
	abstract boolean update(SQLiteDatabase db);
	
	public long persist(SQLiteDatabase db) {
		if (id > 0)
			return update(db) ? id : 0;
		else
			return save(db);
	}

}
