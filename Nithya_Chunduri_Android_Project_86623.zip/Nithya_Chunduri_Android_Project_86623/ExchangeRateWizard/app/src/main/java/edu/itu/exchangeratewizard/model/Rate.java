package edu.itu.exchangeratewizard.model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import edu.itu.exchangeratewizard.common.Util;

/**
 * @author nithya
 *
 */
public class Rate extends AbstractModel {
	
	public static final String TABLE_NAME = "rate";
	public static final String COL_ID = AbstractModel.COL_ID;
	public static final String COL_PAIR = "pair";
	public static final String COL_ASK = "a";
	public static final String COL_BID = "b";
	public static final String COL_DATE = "d1";
	public static final String COL_TIME = "t1";
	public static final String COL_PRICE = "l1";
	
	static String getSql() {
		return Util.concat("CREATE TABLE ", TABLE_NAME, " (",
				COL_ID, " INTEGER PRIMARY KEY AUTOINCREMENT, ",
				COL_PAIR, " TEXT, ",
				COL_ASK, " TEXT, ",
				COL_BID, " TEXT, ",
				COL_DATE, " TEXT, ",
				COL_TIME, " TEXT, ",
				COL_PRICE, " TEXT",
				");");
	}	
	

	@Override
	long save(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		cv.put(COL_PAIR, pair==null ? "" : pair);
		cv.put(COL_ASK, ask==null ? "" : ask);
		cv.put(COL_BID, bid==null ? "" : bid);
		cv.put(COL_DATE, date==null ? "" : date);
		cv.put(COL_TIME, time==null ? "" : time);
		cv.put(COL_PRICE, price==null ? "" : price);
		
		return db.insert(TABLE_NAME, null, cv);
	}

	@Override
	boolean update(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		if (ask != null)
			cv.put(COL_ASK, ask);
		if (bid != null)
			cv.put(COL_BID, bid);
		if (date != null)
			cv.put(COL_DATE, date);
		if (time != null)
			cv.put(COL_TIME, time);
		if (price != null)
			cv.put(COL_PRICE, price);
		
		return db.update(TABLE_NAME, cv, COL_ID+" = ?", new String[]{String.valueOf(id)}) 
				== 1 ? true : false;
	}
	
	public boolean load(SQLiteDatabase db) {
		Cursor cursor = db.query(TABLE_NAME, null, COL_ID+" = ?", new String[]{String.valueOf(id)}, null, null, null);
		try {
			if (cursor.moveToFirst()) {
				reset();
				id = cursor.getLong(cursor.getColumnIndex(COL_ID));
				pair = cursor.getString(cursor.getColumnIndex(COL_PAIR));
				ask = cursor.getString(cursor.getColumnIndex(COL_ASK));
				bid = cursor.getString(cursor.getColumnIndex(COL_BID));
				date = cursor.getString(cursor.getColumnIndex(COL_DATE));
				time = cursor.getString(cursor.getColumnIndex(COL_TIME));
				price = cursor.getString(cursor.getColumnIndex(COL_PRICE));
				return true;
			}
			return false;
		} finally {
			cursor.close();
		}
	}
	
	public boolean find(SQLiteDatabase db) {
		Cursor cursor = db.query(TABLE_NAME, null, COL_PAIR+" = ?", new String[]{pair}, null, null, null);
		try {
			if (cursor.moveToFirst()) {
				reset();
				id = cursor.getLong(cursor.getColumnIndex(COL_ID));
				pair = cursor.getString(cursor.getColumnIndex(COL_PAIR));
				ask = cursor.getString(cursor.getColumnIndex(COL_ASK));
				bid = cursor.getString(cursor.getColumnIndex(COL_BID));
				date = cursor.getString(cursor.getColumnIndex(COL_DATE));
				time = cursor.getString(cursor.getColumnIndex(COL_TIME));
				price = cursor.getString(cursor.getColumnIndex(COL_PRICE));
				return true;
			}
			return false;
		} finally {
			cursor.close();
		}
	}
	
	public boolean modify(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		if (ask != null)
			cv.put(COL_ASK, ask);
		if (bid != null)
			cv.put(COL_BID, bid);
		if (date != null)
			cv.put(COL_DATE, date);
		if (time != null)
			cv.put(COL_TIME, time);
		if (price != null)
			cv.put(COL_PRICE, price);
		
		int num = db.update(TABLE_NAME, cv, COL_PAIR+" = ?", new String[]{pair});
		if (num == 0) save(db);

		return  num > 0 ? true : false;			
	}	
	
	//--------------------------------------------------------------------------

	private String pair;
	private String ask;
	private String bid;
	private String date;
	private String time;
	private String price;
	
	public void reset() {
		super.reset();
		pair = null;
		ask = null;
		bid = null;
		date = null;
		time = null;
		price = null;
	}

	public String getPair() {
		return pair;
	}
	public void setPair(String pair) {
		this.pair = pair;
	}
	public String getAsk() {
		return ask;
	}
	public void setAsk(String ask) {
		this.ask = ask;
	}
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	public Rate() {}
	
	public Rate(long id) {
		this.id = id;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;
		
		return id == ((edu.itu.exchangeratewizard.model.Rate)obj).id;
	}
 
	@Override
	public int hashCode() {
		return 1;
	}	

}
