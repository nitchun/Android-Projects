package edu.itu.exchangeratewizard;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;

import edu.itu.exchangeratewizard.common.Constants;
import edu.itu.exchangeratewizard.common.Util;
import edu.itu.exchangeratewizard.data.QuoteLoader;
import edu.itu.exchangeratewizard.data.RateLoader;
import edu.itu.exchangeratewizard.data.SymbolLoader;
import edu.itu.exchangeratewizard.model.Quote;
import edu.itu.exchangeratewizard.model.Symbol;

/**
 * @author nithya
 *
 */
public class InitTask extends AsyncTask<Void, Void, Integer> {
	
	//private static final String TAG = "InitTask";
	
	private static final String[] MOST_TRADED = {"EUR","JPY","GBP","INR","CHF","CAD","AUD","NZD"};
	
	private Context context;
	private SQLiteDatabase db;

	public InitTask(Context context) {
		super();
		this.context = context;
		db = edu.itu.exchangeratewizard.ExchangeRateWizard.db;
	}

	@Override
	protected Integer doInBackground(Void... params) {

        try {
			//Symbol
			SymbolLoader sl = new SymbolLoader(context, db);
			sl.populate();

			//Quote
			QuoteLoader ql = new QuoteLoader(context, db);
			ql.populate();

			//Ignore
			db.execSQL(Util.concat("UPDATE ", Symbol.TABLE_NAME,
									" SET ", Symbol.COL_TRACKED, "=0 WHERE ", Symbol.COL_CURRENCY_CODE,
									" IN (SELECT ", Quote.COL_SYMBOL, " FROM ", Quote.TABLE_NAME, ")"));

			//Tracked
			ContentValues values = new ContentValues();
			values.put(Symbol.COL_TRACKED, 1);
			db.update(Symbol.TABLE_NAME, values, Symbol.COL_CURRENCY_CODE+" IN (?,?,?,?,?,?,?,?)", MOST_TRADED);

			//Info
			RateLoader rl = new RateLoader(context, db);
			rl.populate();

		} catch (SQLException e) {
			//Log.e(TAG, e.getMessage(), e);
			return Constants.STATUS_FAILED;
		}

		ExchangeRateWizard.setInitialized();
		return Constants.STATUS_SUCCESS;
	}

	@Override
	protected void onPostExecute(Integer result) {
		broadcastStatus(result);
	}
	
	private void broadcastStatus(Integer status) {
		Intent intent = new Intent(Constants.ACTION_INIT);
		intent.putExtra(Constants.EXTRA_STATUS, status);
		context.sendBroadcast(intent);		
	}

}
