package edu.itu.exchangeratewizard.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import edu.itu.exchangeratewizard.common.Constants;
import edu.itu.exchangeratewizard.model.Rate;

/**
 * @author nithya
 *
 */
public class RateLoader {
	
	//private static final String TAG = "RateLoader";
	
	private static final String FILENAME_RESULT = "result.txt";
	
	private Context context;
	private SQLiteDatabase db;
	
	public RateLoader(Context context, SQLiteDatabase db) {
		super();
		this.context = context;
		this.db = db;
	}	
	
	public boolean populate() {
		BufferedReader br = null;
		
		db.beginTransaction();		
		try {
			br = new BufferedReader(new InputStreamReader(context.getAssets().open(FILENAME_RESULT)));
			populate(db, br, Constants.INSERT);
			db.setTransactionSuccessful();
			
		} catch (Exception e) {
			//Log.e(TAG, e.getMessage(), e);
			return false;
		} finally {
			db.endTransaction();
			try {
				if (br!=null) br.close();
			} catch (IOException e) {}
		}
		
		return true;
	}

	/**
	 * "USDEUR=X",0.7802,0.7799,0.78,"3/29/2013","6:55pm"
	 */
	static void populate(SQLiteDatabase db, BufferedReader br, int mode) throws IOException {
		Rate rate = new Rate();
		String line;
		String[] tokens;
		int n = RateUpdater.tags.length;
		while ((line=br.readLine()) != null) {
			line = line.replace("\"", "");
			tokens = line.split(",");
			
			if (tokens.length != n) continue;
			
			rate.reset();
			rate.setPair(tokens[0].split("=")[0]);
			rate.setAsk(tokens[1]);
			rate.setBid(tokens[2]);
			rate.setPrice(tokens[3]);
			rate.setDate(tokens[4]);
			rate.setTime(tokens[5]);
			
			if (mode == Constants.INSERT) {
				rate.persist(db);
			} else if (mode == Constants.UPDATE) {
				rate.modify(db);
			}
		}		
	}	

}
