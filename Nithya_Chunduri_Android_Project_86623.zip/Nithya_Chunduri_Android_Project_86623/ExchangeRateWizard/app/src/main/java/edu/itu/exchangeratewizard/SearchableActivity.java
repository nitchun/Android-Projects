package edu.itu.exchangeratewizard;

import android.app.ListActivity;
import android.app.SearchManager;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import edu.itu.exchangeratewizard.model.Symbol;

/**
 * @author nithya
 *
 */
public class SearchableActivity extends ListActivity {
	
	private Symbol symbol = new Symbol();
	private Resources res;
	private SQLiteDatabase db;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		res = getResources();
		db = ExchangeRateWizard.db;

		handleIntent();
	}

	@Override
	protected void onNewIntent(Intent intent) {
		setIntent(intent);
		handleIntent();
	}

	private void handleIntent() {
		Intent intent = getIntent();
		if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
			String searchQuery = intent.getStringExtra(SearchManager.QUERY);
			doSearch(searchQuery);

		} else if (Intent.ACTION_VIEW.equals(intent.getAction())) {
			Uri detailUri = intent.getData();
			long id = Long.parseLong(detailUri.getLastPathSegment());
			addSymbol(id);
			finish();
		}
	}

	private void doSearch(String query) {
		Cursor c = Symbol.list(edu.itu.exchangeratewizard.ExchangeRateWizard.db, Symbol.NOT_TRACKED, query);
		startManagingCursor(c);
		SimpleCursorAdapter adapter = (SimpleCursorAdapter) getListAdapter();
		if (adapter == null) {
			adapter = new SimpleCursorAdapter(
					this,
					android.R.layout.simple_list_item_2,
					c,
					new String[]{Symbol.COL_CURRENCY_CODE, Symbol.COL_CURRENCY},
					new int[]{android.R.id.text1, android.R.id.text2});

			adapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {

				@Override
				public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
					if (view.getId() == android.R.id.text2) {
						TextView tv = (TextView) view;
						tv.setText(cursor.getString(cursor.getColumnIndex(Symbol.COL_COUNTRY))+" "+cursor.getString(columnIndex));

						int left = res.getIdentifier(cursor.getString(cursor.getColumnIndex(Symbol.COL_FLAG)), "drawable", getBaseContext().getPackageName());
						tv.setCompoundDrawablesWithIntrinsicBounds(left, 0, 0, 0);
						tv.setCompoundDrawablePadding(10);
						return true;
					}
					return false;
				}
			});

			setListAdapter(adapter);

		} else {
			(adapter).changeCursor(c);
		}
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		addSymbol(id);
		finish();
	}

	private void addSymbol(long id) {
		symbol.reset();
		symbol.setId(id);
		symbol.setTracked(true);
		symbol.persist(db);
		symbol.load(db);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {

			@Override
			public void run() {
				Intent newadditionRefresh = new Intent(getApplicationContext(), DataService.class);
				String pair = ExchangeRateWizard.getBaseCurrency()+symbol.getCurrencyCode();
				newadditionRefresh.putExtra(DataService.EXTRA_PAIR, new String[]{pair});
				startService(newadditionRefresh);				
			}
		}, 100);
	}
}
