package edu.itu.exchangeratewizard;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import edu.itu.exchangeratewizard.common.Constants;
import edu.itu.exchangeratewizard.common.Util;
import edu.itu.exchangeratewizard.model.Quote;
import edu.itu.exchangeratewizard.model.Rate;
import edu.itu.exchangeratewizard.model.Symbol;

/**
 * @author nithya
 *
 */
public class InfoActivity extends Activity {
	
	//private static final String TAG = "InfoActivity";
	
	private SQLiteDatabase db;
	private Symbol symbol;
	private Quote quote;
	private Rate rate;
	private String baseCurrency;
	
	private TextView pairText;
	private TextView askText;
	private TextView bidText;
	private TextView priceText;
	private TextView changeText;
	private TextView timeText;
	private LinearLayout layout;
	private LinearLayout menuBar;
	private ImageView processImg;
//	private ImageView progressImg;
	
	private Animation animation;
	private Calendar cal = Calendar.getInstance();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.info);
		
		pairText = (TextView) findViewById(R.id.pair_tv);
		askText = (TextView) findViewById(R.id.ask_tv);
		bidText = (TextView) findViewById(R.id.bid_tv);
		priceText = (TextView) findViewById(R.id.price_tv);
		changeText = (TextView) findViewById(R.id.change_tv);
		timeText = (TextView) findViewById(R.id.time_tv);
		layout = (LinearLayout) findViewById(R.id.chart);
		menuBar = (LinearLayout) findViewById(R.id.menu_bar);
		processImg = (ImageView) findViewById(R.id.process_iv);
//		progressImg = (ImageView) findViewById(R.id.progress_iv);
		
		animation = AnimationUtils.loadAnimation(this, R.anim.progress);
		
		db = ExchangeRateWizard.db;
		baseCurrency = ExchangeRateWizard.getBaseCurrency();
		long symbolId = getIntent().getLongExtra(Symbol.COL_ID, 0);
		
		symbol = new Symbol(symbolId);
		symbol.load(db);
		
		quote = new Quote();
		quote.setSymbol(symbol.getCurrencyCode());
		quote.find(db);
		
		rate = new Rate();
		load();
		
		if (!hasHistory("USD"+symbol.getCurrencyCode()))
			menuBar.setVisibility(View.GONE);
		
/*		RefreshTask refresh = new RefreshTask();
		refresh.execute(rate.getPair());*/
	}
	
	private void load() {
		rate.reset();
		rate.setPair(baseCurrency+symbol.getCurrencyCode());
		rate.find(db);
		
		pairText.setText(rate.getPair());
		askText.setText(rate.getAsk());
		bidText.setText(rate.getBid());
		priceText.setText(rate.getPrice());
		
		if (!TextUtils.isEmpty(rate.getPrice())) {
			double latest = Util.parseDouble(rate.getPrice());
			double daily = Util.parseDouble(quote.getPrice());
			
			if (!ExchangeRateWizard.DEFAULT_CURRENCY.equals(baseCurrency)) {
				Quote baseQuote = new Quote();
				baseQuote.setSymbol(baseCurrency);
				baseQuote.find(db);
				
				daily /= Util.parseDouble(baseQuote.getPrice());
			}
			
			double change = Util.parseDouble(String.format("%.4f", latest-daily));
			if (change != 0) {
				changeText.setText(String.valueOf(change));
				if (change > 0) 
					changeText.setTextColor(Color.GREEN);
				else if (change < 0) 
					changeText.setTextColor(Color.RED);
			} else {
				changeText.setText("-");
				changeText.setTextColor(getResources().getColor(R.color.txt));
			}
		}
		
		timeText.setText(Util.getString(rate.getDate())+" "+Util.getString(rate.getTime()));		
	}

	@Override
	protected void onResume() {
		super.onResume();
		registerReceiver(refreshStatusReceiver, new IntentFilter(Constants.ACTION_REFRESH));
	}

	@Override
	protected void onPause() {
		unregisterReceiver(refreshStatusReceiver);
		processImg.clearAnimation();
		processImg.setVisibility(View.INVISIBLE);
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
	
	private XYMultipleSeriesRenderer getRenderer() {
	    XYMultipleSeriesRenderer renderer = new XYMultipleSeriesRenderer();
//	    renderer.setApplyBackgroundColor(true);
//		renderer.setBackgroundColor(getResources().getColor(R.color.bkg));	    
	    renderer.setAxisTitleTextSize(16);
	    renderer.setChartTitleTextSize(20);
	    renderer.setLabelsTextSize(15);
	    renderer.setLegendTextSize(15);
	    renderer.setPointSize(2f);
	    renderer.setShowGridX(true);
	    renderer.setGridColor(getResources().getColor(R.color.txt));
	    renderer.setMargins(new int[] {10, 15, 10, 10});
	    renderer.setPanEnabled(true, false);
	    renderer.setZoomButtonsVisible(true);
	    
	    Date to = cal.getTime();
	    renderer.setXAxisMax(new Date(to.getYear(), to.getMonth(), to.getDate()).getTime());
	    cal.add(Calendar.DATE, -ExchangeRateWizard.getVisibleRange());
	    Date from = cal.getTime();
	    renderer.setXAxisMin(new Date(from.getYear(), from.getMonth(), from.getDate()).getTime());
	    
	    XYSeriesRenderer r = new XYSeriesRenderer();
	    r.setColor(Color.BLUE);
	    r.setPointStyle(PointStyle.CIRCLE);//square
	    r.setFillPoints(true);
	    r.setFillBelowLine(true);
	    r.setFillBelowLineColor(getResources().getColor(R.color.bkg));
	    renderer.addSeriesRenderer(r);

	    renderer.setAxesColor(Color.DKGRAY);
	    renderer.setLabelsColor(Color.LTGRAY);
	    return renderer;		
	}
	
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.close_btn:
			finish();
			break;
			
		case R.id.show_btn:			
			v.setVisibility(View.GONE);
			
			ChartTask task = new ChartTask();
			task.execute();
			break;
		}
	}
	
	private boolean hasHistory(String pair) {
		try {
			String[] csvs = getAssets().list("hist");
			for(String csv : csvs) {
				if (csv.contains(pair)) return true;
			}
		} catch (IOException e) {}
		return false;
	}
	
	//-------------------------------------------------------------------
	
/*	private class RefreshTask extends AsyncTask<String, Void, Boolean> {

		@Override
		protected void onPreExecute() {
			processImg.setVisibility(View.VISIBLE);
			processImg.startAnimation(animation);
		}

		@Override
		protected Boolean doInBackground(String... params) {
			Downloader downloader = new Downloader(getApplicationContext());
			if (!downloader.isConnected()) return false;
			
			RateUpdater ru = new RateUpdater(db, downloader);
			return ru.populate(rate.getPair());
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			processImg.clearAnimation();
			processImg.setVisibility(View.INVISIBLE);
			
			if (result) load();
			else Toast.makeText(InfoActivity.this, getString(R.string.update_failed), Toast.LENGTH_SHORT).show();
		}		
		
	}*/
	
	private class ChartTask extends AsyncTask<Date, Void, Void> {
		private TimeSeries series;
		
		@Override
		protected void onPreExecute() {
			processImg.setVisibility(View.VISIBLE);
			processImg.startAnimation(animation);
			
			series = new TimeSeries("USD/"+symbol.getCurrencyCode());
		}

		@Override
		protected Void doInBackground(Date... params) {
			BufferedReader br = null;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			
			try {
				br = new BufferedReader(new InputStreamReader(getAssets().open("hist/USD"+symbol.getCurrencyCode()+".csv")));
				
				String line=br.readLine(), date, close;
				String[] tokens;
				int i=0, N= ExchangeRateWizard.getTotalRange();
				while ((line=br.readLine()) != null) {
					if (++i > N) break;
					
					tokens = line.split(",");
					date = tokens[0];
					close = tokens[4];
					
					if (!TextUtils.isEmpty(date) && !TextUtils.isEmpty(close))
						series.add(sdf.parse(date), Util.parseDouble(close));
				}
				
			} catch (Exception e) {
				//Log.e(TAG, e.getMessage(), e);
			} finally {
				try {
					if (br!=null) br.close();
				} catch (IOException e) {}
			}			
			
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			processImg.clearAnimation();
			processImg.setVisibility(View.INVISIBLE);
			
			XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
			dataset.addSeries(series);
			String format = ExchangeRateWizard.getVisibleRange() > 90 ? "MMM yyyy" : "d MMM";
			
			GraphicalView chartView = ChartFactory.getTimeChartView(InfoActivity.this, dataset, getRenderer(), format);
			layout.addView(chartView, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		}
	}
	
	private Runnable success = new Runnable() {
		
		@Override
		public void run() {
			load();
		}
	};	
	
	private BroadcastReceiver refreshStatusReceiver = new  BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent != null && Constants.ACTION_REFRESH.equals(intent.getAction())) {
				switch (intent.getIntExtra(Constants.EXTRA_STATUS, 100)) {
				case Constants.STATUS_SUCCESS:
					runOnUiThread(success);					
					break;
				}
			}
		}
	};	

}
