package edu.itu.exchangeratewizard.model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import edu.itu.exchangeratewizard.common.Util;

/**
 * @author nithya
 *
 */
public class Symbol extends AbstractModel {
	
	public static final String TABLE_NAME = "symbol";
	public static final String COL_ID = AbstractModel.COL_ID;
	public static final String COL_COUNTRY = "country";
	public static final String COL_CURRENCY = "currency";
	public static final String COL_CURRENCY_CODE = "currency_code";
	public static final String COL_FLAG = "flag";
	public static final String COL_HEX = "hex";
	public static final String COL_TRACKED = "tracked";
	public static final String COL_ORDER = "display_order";
	
	public static final String TRACKED = "1";
	public static final String NOT_TRACKED = "0";
	
	static String getSql() {
		return Util.concat("CREATE TABLE ", TABLE_NAME, " (",
				COL_ID, " INTEGER PRIMARY KEY AUTOINCREMENT, ",
				COL_COUNTRY, " TEXT COLLATE NOCASE, ",
				COL_CURRENCY, " TEXT COLLATE NOCASE, ",
				COL_CURRENCY_CODE, " TEXT COLLATE NOCASE, ",
				COL_FLAG, " TEXT, ",
				COL_HEX, " TEXT, ",
				COL_TRACKED, " INTEGER, ",
				COL_ORDER, " INTEGER",
				");");
	}	

	@Override
	long save(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		cv.put(COL_COUNTRY, country==null ? "" : country);
		cv.put(COL_CURRENCY, currency==null ? "" : currency);
		cv.put(COL_CURRENCY_CODE, currencyCode==null ? "" : currencyCode);
		cv.put(COL_FLAG, flag==null ? "" : flag);
		cv.put(COL_HEX, hex==null ? "" : hex);
		cv.put(COL_TRACKED, isTracked==null ? -1 : (isTracked ? 1 : 0));
		cv.put(COL_ORDER, order==null ? 0 : order);
		
		return db.insert(TABLE_NAME, null, cv);
	}

	@Override
	boolean update(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		if (isTracked != null) {
			cv.put(COL_TRACKED, isTracked ? 1 : 0);
			
			if (isTracked) cv.put(COL_ORDER, System.currentTimeMillis());
			else cv.put(COL_ORDER, 0);
		}
		if (order != null)
			cv.put(COL_ORDER, order);		
		
		return db.update(TABLE_NAME, cv, COL_ID+" = ?", new String[]{String.valueOf(id)}) 
				== 1 ? true : false;
	}
	
	public boolean load(SQLiteDatabase db) {
		Cursor cursor = db.query(TABLE_NAME, null, COL_ID+" = ?", new String[]{String.valueOf(id)}, null, null, null);
		try {
			if (cursor.moveToFirst()) {
				reset();
				id = cursor.getLong(cursor.getColumnIndex(COL_ID));
				country = cursor.getString(cursor.getColumnIndex(COL_COUNTRY));
				currency = cursor.getString(cursor.getColumnIndex(COL_CURRENCY));
				currencyCode = cursor.getString(cursor.getColumnIndex(COL_CURRENCY_CODE));
				flag = cursor.getString(cursor.getColumnIndex(COL_FLAG));
				hex = cursor.getString(cursor.getColumnIndex(COL_HEX));
				isTracked = cursor.getInt(cursor.getColumnIndex(COL_TRACKED)) == 1 ? true : false;
				order = cursor.getLong(cursor.getColumnIndex(COL_ORDER));
				return true;
			}
			return false;
		} finally {
			cursor.close();
		}
	}
	
	/**
	 * @param db
	 * @param args {isTracked, query}
	 * @return
	 */
	public static Cursor list(SQLiteDatabase db, String... args) {
		String isTracked = (args!=null && args.length>0) ? args[0] : null;
		String query = (args!=null && args.length>1) ? args[1] : null;
		
		String[] columns = {COL_ID, COL_COUNTRY, COL_CURRENCY, COL_CURRENCY_CODE, COL_FLAG};
		String selection = "1 = 1";
		List<String> selectionArgs = new ArrayList<String>();
		
		if (isTracked != null) {
			selection += " AND "+COL_TRACKED + " = ?";
			selectionArgs.add(isTracked);
		}
		if (query != null) {
			selection += " AND ("+COL_COUNTRY + " like ?";
			selection += " OR "+COL_CURRENCY + " like ?";
			selection += " OR "+COL_CURRENCY_CODE + " like ?)";
			selectionArgs.add(query+"%");
			selectionArgs.add(query+"%");
			selectionArgs.add(query+"%");
		}		
		
		return db.query(TABLE_NAME, columns, selection, selectionArgs.toArray(new String[]{}), null, null, null);
	}
	
	public boolean find(SQLiteDatabase db) {
		Cursor cursor = db.query(TABLE_NAME, null, COL_CURRENCY_CODE+" = ?", new String[]{currencyCode}, null, null, null);
		try {
			if (cursor.moveToFirst()) {
				reset();
				id = cursor.getLong(cursor.getColumnIndex(COL_ID));
				country = cursor.getString(cursor.getColumnIndex(COL_COUNTRY));
				currency = cursor.getString(cursor.getColumnIndex(COL_CURRENCY));
				currencyCode = cursor.getString(cursor.getColumnIndex(COL_CURRENCY_CODE));
				flag = cursor.getString(cursor.getColumnIndex(COL_FLAG));
				hex = cursor.getString(cursor.getColumnIndex(COL_HEX));
				isTracked = cursor.getInt(cursor.getColumnIndex(COL_TRACKED)) == 1 ? true : false;
				order = cursor.getLong(cursor.getColumnIndex(COL_ORDER));
				return true;
			}
			return false;
		} finally {
			cursor.close();
		}
	}	
	
	//--------------------------------------------------------------------------

	private String country;
	private String currency;
	private String currencyCode;
	private String flag;
	private String hex;
	private Boolean isTracked;
	private Long order;
	
	public void reset() {
		super.reset();
		country = null;
		currency = null;
		currencyCode = null;
		flag = null;
		hex = null;
		isTracked = null;
		order = null;
	}

	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getHex() {
		return hex;
	}
	public void setHex(String hex) {
		this.hex = hex;
	}	
	public boolean isTracked() {
		return isTracked!=null ? isTracked : false;
	}
	public void setTracked(boolean isTracked) {
		this.isTracked = isTracked;
	}
	public long getOrder() {
		return order!=null ? order : 0;
	}
	public void setOrder(long order) {
		this.order = order;
	}

	public Symbol() {}
	
	public Symbol(long id) {
		this.id = id;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;
		
		return id == ((Symbol)obj).id;
	}
 
	@Override
	public int hashCode() {
		return 1;
	}	

}
