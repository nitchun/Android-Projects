package edu.itu.exchangeratewizard.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import edu.itu.exchangeratewizard.common.Constants;

/**
 * @author nithya
 *
 */
public class QuoteLoader {
	
	//private static final String TAG = "QuoteLoader";
	
	private static final String FILENAME_QUOTE = "quote.xml";
	
	private Context context;
	private SQLiteDatabase db;
	
	public QuoteLoader(Context context, SQLiteDatabase db) {
		super();
		this.context = context;
		this.db = db;
	}	
	
	public boolean populate() {
		InputStream is = null;
		
		db.beginTransaction();		
		try {
			is = context.getAssets().open(FILENAME_QUOTE);
			populate(db, is);
			db.setTransactionSuccessful();
			
		} catch (Exception e) {
			//Log.e(TAG, e.getMessage(), e);
			return false;
		} finally {
			db.endTransaction();
			try {
				if (is!=null) is.close();
			} catch (IOException e) {}
		}
		
		return true;
	}
	
	private void populate(SQLiteDatabase db, InputStream is) throws ParserConfigurationException, SAXException, IOException {
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		QuoteHandler handler = new QuoteHandler(db, Constants.INSERT);
		parser.parse(is, handler);
	}

}
