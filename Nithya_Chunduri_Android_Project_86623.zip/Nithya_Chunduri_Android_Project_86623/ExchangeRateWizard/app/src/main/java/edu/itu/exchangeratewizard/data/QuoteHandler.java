package edu.itu.exchangeratewizard.data;

import android.database.sqlite.SQLiteDatabase;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import edu.itu.exchangeratewizard.common.Constants;
import edu.itu.exchangeratewizard.model.Quote;

/**
 * @author nithya
 *
 */
public class QuoteHandler extends DefaultHandler {
	
	private static final String ROW = "resource";
	private static final String COL = "field";
	
	private SQLiteDatabase db;
	private int mode;
	private Quote obj;
	private StringBuilder sb;

	public QuoteHandler(SQLiteDatabase db, int mode) {
		super();
		this.db = db;
		this.mode = mode;
		obj = new Quote();
		sb = new StringBuilder();
	}
	
	private String column;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		column = null;
		if (ROW.equals(localName)) {
			obj.reset();
			
		} else if (COL.equals(localName)) {
			column = attributes.getValue("name");
		}
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		if (column != null) {
			sb.setLength(0);
			for (int i=start; i<start+length; i++) {
				sb.append(ch[i]);
			}
			String str = sb.toString();
			if ("symbol".equals(column)) {
				int eqIdx = str.indexOf('=');
				if (eqIdx != -1) str = str.substring(0, eqIdx);
			}
			obj.set(column, str);
		}
	}	

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		column = null;
		if (ROW.equals(localName)) {
			if (mode == Constants.INSERT) {
				obj.persist(db);
			} else if (mode == Constants.UPDATE) {
				obj.modify(db);
			}
		}		
	}	

}
