package edu.itu.exchangeratewizard.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;

import edu.itu.exchangeratewizard.model.Symbol;

/**
 * @author nithya
 *
 */
public class SymbolLoader {
	
	//private static final String TAG = "SymbolLoader";
	
	private static final String FILENAME_SYMBOLS = "symbols.xml";
	private static final String TAG_ROW = "row";
	private static final String TAG_COL = "col";
	
	private Context context;
	private SQLiteDatabase db;
	
	public SymbolLoader(Context context, SQLiteDatabase db) {
		super();
		this.context = context;
		this.db = db;
	}

	public boolean populate() {
		InputStream is = null;
		
		db.beginTransaction();		
		try {
			is = context.getAssets().open(FILENAME_SYMBOLS);
			populate(db, is);
			db.setTransactionSuccessful();
			
		} catch (Exception e) {
			//Log.e(TAG, e.getMessage(), e);
			return false;
		} finally {
			db.endTransaction();
			try {
				if (is!=null) is.close();
			} catch (IOException e) {}
		}
		
		return true;
	}

	private void populate(SQLiteDatabase db, InputStream is) throws XmlPullParserException, IOException {
		
		XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.setNamespaceAware(false);
        XmlPullParser parser = factory.newPullParser();
        
		parser.setInput(is, null);
		int eventType = parser.getEventType();
		String tag;
		int colIdx = 0;
		boolean copy = false;
		
		Symbol obj = new Symbol();
		while (eventType != XmlPullParser.END_DOCUMENT) {
			switch (eventType) {
			case XmlPullParser.START_TAG:
				copy = false;
				tag = parser.getName();
				if (TAG_ROW.equals(tag)) {
					obj.reset();
					colIdx = 0;
				} else if (TAG_COL.equals(tag)) {
					colIdx++;
					copy = true;
				}
				break;
				
			case XmlPullParser.TEXT:
				if (copy) {
					switch(colIdx) {
					case 1:
						obj.setFlag(parser.getText());
						break;
					case 2:
						obj.setCountry(parser.getText());
						break;
					case 3:
						obj.setCurrency(parser.getText());
						break;
					case 4:
						obj.setCurrencyCode(parser.getText());
						break;
					case 6:
						obj.setHex(parser.getText());
						break;
					}
				}
				break;
				
			case XmlPullParser.END_TAG:
				copy = false;
				tag = parser.getName();
				if (TAG_ROW.equals(tag)) {
					obj.persist(db);
				}
				break;
			}
			
			eventType = parser.next();
		}		
	}	

}
