package edu.itu.exchangeratewizard.data;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

import java.net.URI;

import edu.itu.exchangeratewizard.ExchangeRateWizard;

/**
 * @author nithya
 *
 */
public class Downloader {
	
	//private static final String TAG = "Downloader";

	private ConnectivityManager connMgr;
	private HttpClient client;
	
	public Downloader(Context context) {
		super();
		connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		client = new DefaultHttpClient();
	}

	public String getResult(String url) {
		String result = null;
		
		if (isConnected()) {
			try {
				HttpGet request = new HttpGet(new URI(url));
				HttpResponse response = client.execute(request);
				
				BasicResponseHandler handler = new BasicResponseHandler();
				result = handler.handleResponse(response);
				
			} catch (Exception e) {
				//Log.e(TAG, e.getMessage(), e);
			}
		}
		
		return result;
	}
	
	public boolean isConnected() {
		NetworkInfo netInfo = connMgr.getActiveNetworkInfo();
		return netInfo!=null && netInfo.getState()==NetworkInfo.State.CONNECTED && 
				(!ExchangeRateWizard.isUseWifi() || netInfo.getType()==ConnectivityManager.TYPE_WIFI);
	}
}
