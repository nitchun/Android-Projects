package edu.itu.exchangeratewizard;

import android.app.Application;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;

import edu.itu.exchangeratewizard.model.DbHelper;

/**
 * @author nithya
 *
 */
public class ExchangeRateWizard extends Application {
	
	public static DbHelper dbHelper;
	public static SQLiteDatabase db;
	public static SharedPreferences sp;
	
	public static final String INITIALIZED = "initialized";
	public static final String LAST_UPDATE = "last_update";
	public static final String IN_PROGRESS = "in_progress";
	
	public static final String BASE_CURRENCY = "base_currency";
	public static final String BASE_AMOUNT = "base_amt";
	public static final String HISTORY_VISIBLE = "hist_visible";
	public static final String HISTORY_TOTAL = "hist_total";
	public static final String USE_WIFI = "use_wifi";
	/*	public static final String UPDATE_FREQUENCY = "update_freq";
	public static final String PREF_PAIR = "pref_pair";
	public static final String REFRESH_RATE = "refresh_rate";*/	
	
	public static final String DEFAULT_CURRENCY = "USD";
	public static final String DEFAULT_AMOUNT = "1.0";
	public static final String DEFAULT_VISIBLE = "90";
	public static final String DEFAULT_TOTAL = "365";
/*	public static final String DEFAULT_UPDATE = "1";//1 day
	public static final String DEFAULT_PAIR = "EURUSD";
	public static final String DEFAULT_REFRESH = "30";//30 min	
*/	
	public static final long MIN_UPDATE = 24*60*60*1000;//1 day
/*	public static final int MIN_REFRESH = 1;//1 min
*/	
	@Override
	public void onCreate() {
		super.onCreate();
		
		PreferenceManager.setDefaultValues(this, R.xml.settings, false);
		sp = PreferenceManager.getDefaultSharedPreferences(this);
		
		dbHelper = new DbHelper(this);
		db = dbHelper.getWritableDatabase();
		
		setProgress(false);
	}
	
	public static boolean isInitialized() {
		return sp.getBoolean(INITIALIZED, false);
	}
	public static void setInitialized() {
		sp.edit().putBoolean(INITIALIZED, true).commit();
	}
	
	public static String getBaseCurrency() {
		return sp.getString(BASE_CURRENCY, DEFAULT_CURRENCY);
	}
	public static void setBaseCurrency(String currencyCode) {
		sp.edit().putString(BASE_CURRENCY, currencyCode).commit();
	}
	
	public static float getBaseAmount() {
		return Float.parseFloat(sp.getString(BASE_AMOUNT, DEFAULT_AMOUNT));
	}
/*	public static void setBaseAmount(String amt) {
		sp.edit().putString(BASE_AMOUNT, amt).commit();
	}*/	
	
	public static boolean isUseWifi() {
		return sp.getBoolean(USE_WIFI, false);
	}
	
/*	public static long getLastUpdate() {
		return sp.getLong(LAST_UPDATE, 0);
	}*/
	public static void setLastUpdate(long time) {
		sp.edit().putLong(LAST_UPDATE, time).commit();
	}
	public static boolean isReadyForUpdate(long now) {
		return (now - sp.getLong(LAST_UPDATE, 0) > MIN_UPDATE) ? true : false; 
	}
	
/*	public static String getPreferredPair() {
		return sp.getString(PREF_PAIR, DEFAULT_PAIR);
	}*/

	/**
	 * @return milliseconds
	 */
/*	public static long getRefreshRate() {
		return Integer.parseInt(sp.getString(REFRESH_RATE, DEFAULT_REFRESH))*60*1000;
	}*/
	
	/**
	 * @return milliseconds
	 */
/*	public static long getUpdateFrequency() {
		return Integer.parseInt(sp.getString(UPDATE_FREQUENCY, DEFAULT_UPDATE))*24*60*60*1000;
	}*/
	
	public static int getVisibleRange() {
		return Integer.parseInt(sp.getString(HISTORY_VISIBLE, DEFAULT_VISIBLE));
	}
	
	public static int getTotalRange() {
		return Integer.parseInt(sp.getString(HISTORY_TOTAL, DEFAULT_TOTAL));
	}
	
	public static boolean inProgress() {
		return sp.getBoolean(IN_PROGRESS, false);
	}
	public static void setProgress(boolean progress) {
		sp.edit().putBoolean(IN_PROGRESS, progress).commit();
	}	

}
