package edu.itu.exchangeratewizard.common;

/**
 * @author nithya
 *
 */
public class Constants {

	public static final String ACTION_INIT = "edu.itu.exchangeratewizard.INIT";
//	public static final String ACTION_UPDATE = "edu.itu.exchangeratewizard.UPDATE";
	public static final String ACTION_REFRESH = "edu.itu.exchangeratewizard.REFRESH";
	public static final String EXTRA_STATUS = "status";
	public static final int STATUS_NOCONNECTIVITY = 2;
	public static final int STATUS_INPROGRESS = 0;
	public static final int STATUS_SUCCESS = 1;
	public static final int STATUS_FAILED = -1;
	
	public static final String PAIR = "s";
	public static final String ASK = "a";
	public static final String BID = "b";
	public static final String LAST_TRADE_DATE = "d1";
	public static final String LAST_TRADE_PRICE = "l1";
	public static final String LAST_TRADE_TIME = "t1";
	
	public static final int INSERT = 1;
	public static final int UPDATE = 2;

}
