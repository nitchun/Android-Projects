package edu.itu.exchangeratewizard.data;

import android.database.sqlite.SQLiteDatabase;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import edu.itu.exchangeratewizard.common.Constants;

/**
 * @author nithya
 *
 */
public class QuoteUpdater {
	
	//private static final String TAG = "QuoteUpdater";
	
	public static final String URL = "http://finance.yahoo.com/webservice/v1/symbols/allcurrencies/quote";
	
	private SQLiteDatabase db;
	
	public QuoteUpdater(SQLiteDatabase db) {
		super();
		this.db = db;
	}	
	
	public boolean populate() {
		
		db.beginTransaction();		
		try {
			populate(db, new InputSource(URL));
			db.setTransactionSuccessful();
			
		} catch (Exception e) {
			//Log.e(TAG, e.getMessage(), e);
			return false;
		} finally {
			db.endTransaction();
		}
		
		return true;
	}
	
	private void populate(SQLiteDatabase db, InputSource is) throws ParserConfigurationException, SAXException, IOException {
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		QuoteHandler handler = new QuoteHandler(db, Constants.UPDATE);
		parser.parse(is, handler);
	}	

}
