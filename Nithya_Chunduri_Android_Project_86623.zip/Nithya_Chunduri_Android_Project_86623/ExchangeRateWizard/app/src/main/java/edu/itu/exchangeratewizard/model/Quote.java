package edu.itu.exchangeratewizard.model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import edu.itu.exchangeratewizard.common.Util;
import edu.itu.exchangeratewizard.model.*;
import edu.itu.exchangeratewizard.model.AbstractModel;

/**
 * @author nithya
 *
 */
public class Quote extends edu.itu.exchangeratewizard.model.AbstractModel {

	public static final String TABLE_NAME = "quote";
	public static final String COL_ID = edu.itu.exchangeratewizard.model.AbstractModel.COL_ID;
	public static final String COL_NAME = "name";
	public static final String COL_PRICE = "price";
	public static final String COL_SYMBOL = "symbol";
	public static final String COL_TS = "ts";
	
	static String getSql() {
		return Util.concat("CREATE TABLE ", TABLE_NAME, " (",
				COL_ID, " INTEGER PRIMARY KEY AUTOINCREMENT, ",
				COL_NAME, " TEXT, ",
				COL_PRICE, " TEXT, ",
				COL_SYMBOL, " TEXT, ",
				COL_TS, " TEXT",
				");");
	}	

	@Override
	long save(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		cv.put(COL_NAME, name==null ? "" : name);
		cv.put(COL_PRICE, price==null ? "" : price);
		cv.put(COL_SYMBOL, symbol==null ? "" : symbol);
		cv.put(COL_TS, ts==null ? "" : ts);
		
		return db.insert(TABLE_NAME, null, cv);
	}

	@Override
	boolean update(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		if (price != null)
			cv.put(COL_PRICE, price);
		if (ts != null)
			cv.put(COL_TS, ts);
		
		return db.update(TABLE_NAME, cv, COL_ID+" = ?", new String[]{String.valueOf(id)}) 
				== 1 ? true : false;
	}
	
	public boolean load(SQLiteDatabase db) {
		Cursor cursor = db.query(TABLE_NAME, null, COL_ID+" = ?", new String[]{String.valueOf(id)}, null, null, null);
		try {
			if (cursor.moveToFirst()) {
				reset();
				id = cursor.getLong(cursor.getColumnIndex(COL_ID));
				name = cursor.getString(cursor.getColumnIndex(COL_NAME));
				price = cursor.getString(cursor.getColumnIndex(COL_PRICE));
				symbol = cursor.getString(cursor.getColumnIndex(COL_SYMBOL));
				ts = cursor.getString(cursor.getColumnIndex(COL_TS));
				return true;
			}
			return false;
		} finally {
			cursor.close();
		}
	}
	
	public boolean find(SQLiteDatabase db) {
		Cursor cursor = db.query(TABLE_NAME, null, COL_SYMBOL+" = ?", new String[]{symbol}, null, null, null);
		try {
			if (cursor.moveToFirst()) {
				reset();
				id = cursor.getLong(cursor.getColumnIndex(COL_ID));
				name = cursor.getString(cursor.getColumnIndex(COL_NAME));
				price = cursor.getString(cursor.getColumnIndex(COL_PRICE));
				symbol = cursor.getString(cursor.getColumnIndex(COL_SYMBOL));
				ts = cursor.getString(cursor.getColumnIndex(COL_TS));
				return true;
			}
			return false;
		} finally {
			cursor.close();
		}
	}
	
	public boolean modify(SQLiteDatabase db) {
		ContentValues cv = new ContentValues();
		if (price != null)
			cv.put(COL_PRICE, price);
		if (ts != null)
			cv.put(COL_TS, ts);
		
		int num = db.update(TABLE_NAME, cv, COL_SYMBOL+" = ?", new String[]{symbol});
		if (num == 0) save(db);

		return  num > 0 ? true : false;		
	}	
	
	//--------------------------------------------------------------------------

	private String name;
	private String price;
	private String symbol;
	private String ts;
	
	public void reset() {
		super.reset();
		name = null;
		price = null;
		symbol = null;
		ts = null;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getTs() {
		return ts;
	}
	public void setTs(String ts) {
		this.ts = ts;
	}	

	public void set(String field, String value) {
		if (TextUtils.isEmpty(field)) return;
		
		if (COL_NAME.equals(field)) {
			name = value;
		} else if (COL_PRICE.equals(field)) {
			price = value;
		} else if (COL_SYMBOL.equals(field)) {
			symbol = value;
		} else if (COL_TS.equals(field)) {
			ts = value;
		}
	}
	
	public Quote() {}
	
	public Quote(long id) {
		this.id = id;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;
		
		return id == ((edu.itu.exchangeratewizard.model.Quote)obj).id;
	}
 
	@Override
	public int hashCode() {
		return 1;
	}	

}
