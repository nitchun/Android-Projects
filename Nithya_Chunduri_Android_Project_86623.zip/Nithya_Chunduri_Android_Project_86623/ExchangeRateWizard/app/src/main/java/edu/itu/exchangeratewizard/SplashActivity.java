package edu.itu.exchangeratewizard;


import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import edu.itu.exchangeratewizard.common.Constants;

/**
 * @author nithya
 *
 */
public class SplashActivity extends Activity {
	
	private Typeface font;
	private InitTask init;

	private TextView tv1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		if (ExchangeRateWizard.isInitialized()) {
			proceed();
			
		} else {
			init = new InitTask(getApplicationContext());
			init.execute();
		}
		
		setContentView(R.layout.splash);
		
		font = Typeface.createFromAsset(getAssets(), "fonts/OpenSans-Semibold.ttf");
		tv1 = (TextView) findViewById(R.id.textView1);
		tv1.setTypeface(font);
	}
	
	private void proceed() {
		startActivity(new Intent(this, MainActivity.class));
		finish();
	}	

	@Override
	protected void onResume() {
		super.onResume();
		registerReceiver(initStatusReceiver, new IntentFilter(Constants.ACTION_INIT));
	}

	@Override
	protected void onPause() {
		unregisterReceiver(initStatusReceiver);
		super.onPause();
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}	
	
	//---------------------------------------------------------------------------
	
	private BroadcastReceiver initStatusReceiver = new  BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent != null && Constants.ACTION_INIT.equals(intent.getAction())) {
				switch (intent.getIntExtra(Constants.EXTRA_STATUS, 100)) {
				case Constants.STATUS_SUCCESS:
					runOnUiThread(new Runnable() {
						
						@Override
						public void run() {
							proceed();
						}
					});
					break;
					
				case Constants.STATUS_FAILED:
					Toast.makeText(context, getString(R.string.init_failed), Toast.LENGTH_SHORT).show();
					finish();
					break;
				}
			}
		}
	};	
	
}
